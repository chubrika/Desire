import { Component } from '@angular/core';
@Component({
    selector: 'carousel',
    templateUrl: './carousel.template.html'
})

export class CarouselComponent {

    constructor() {
    }
    ngOnInit() {
    }
}
